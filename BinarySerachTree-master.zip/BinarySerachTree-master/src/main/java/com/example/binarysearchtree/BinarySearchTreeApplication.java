package com.example.binarysearchtree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BinarySearchTreeApplication {

    public static void main(String[] args) {
        SpringApplication.run(BinarySearchTreeApplication.class, args);
    }

}
