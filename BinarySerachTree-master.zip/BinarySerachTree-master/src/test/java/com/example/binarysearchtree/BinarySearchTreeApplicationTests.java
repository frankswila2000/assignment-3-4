package com.example.binarysearchtree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BinarySearchTreeApplicationTests {

    @Test
    void contextLoads() {
    }

}
